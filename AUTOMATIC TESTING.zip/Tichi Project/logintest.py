from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://tichi-app-webapp-stage.web.app")
wait = WebDriverWait(driver, 10)

sign_in =wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "Sign In")))
sign_in.click()
email=wait.until(EC.visibility_of_element_located((By.ID, "email")))
email.send_keys("23eca34@karpagamtech.ac.in")
continue_button=wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div[2]/div/form/button")))
continue_button.click()
password=wait.until(EC.visibility_of_element_located((By.ID, "password")))
password.send_keys("Ezhil@2006")
login_button=wait.until(EC.element_to_be_clickable((By.XPATH,"/html/body/div[1]/div[2]/div/form/button")))
login_button.click()

time.sleep(3)
print("Website logged in successfully")
driver.quit()  